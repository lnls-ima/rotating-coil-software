SOFTWARE AND DRIVER INSTALLATION
Fast Digital Integrator FDI2056
Copyright (c) 2015 Metrolab Technology SA, Plan-les-Ouates, Switzerland

1. First download and install:
   - LabVIEW 2010 SP1 Run-Time Engine (http://joule.ni.com/nidu/cds/view/p/id/2292/lang/en)
   - NI-VISA 5.1.1 Run-Time Engine (http://joule.ni.com/nidu/cds/view/p/id/2662/lang/en)
2. Execute the included setup program to install FDI2056 Software v. 2.0.
